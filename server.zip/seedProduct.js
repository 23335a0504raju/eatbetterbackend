const mongoose = require('mongoose');
const Product = require('./models/Product'); // Adjust path if needed
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('✅ MongoDB connected');
  seed();
}).catch(err => {
  console.error('❌ Connection error:', err);
});

async function seed() {
  try {
    // Optional: clear existing products
    await Product.deleteMany({});

    const products = [
      {
        name: "Rasgulla",
        description: "Soft and juicy Bengali sweet",
        price: 180,
        category: "meetha",
        imageUrl: "https://example.com/images/rasgulla.jpg",
        isBestSeller: true,
        stock: 60
      },
      {
        name: "Foxtail Millet Mixture",
        description: "Crispy mixture with foxtail millet and traditional spices",
        price: 120,
        category: "namkeen",
        imageUrl: "https://example.com/images/foxtail_mixture.jpg",
        isBestSeller: true,
        stock: 100
      },
      {
        name: "Ragi Cookies",
        description: "Nutritious sweet cookies made with ragi and jaggery",
        price: 90,
        category: "meetha",
        imageUrl: "https://example.com/images/ragi_cookies.jpg",
        isBestSeller: false,
        stock: 50
      },
      {
        name: "Bajra Chakli",
        description: "Crunchy spiral snack made from bajra flour and spices",
        price: 75,
        category: "namkeen",
        imageUrl: "https://example.com/images/bajra_chakli.jpg",
        isBestSeller: true,
        stock: 80
      },
      {
        name: "Little Millet Ladoo",
        description: "Sweet balls made from little millet, jaggery, and ghee",
        price: 150,
        category: "meetha",
        imageUrl: "https://example.com/images/little_millet_ladoo.jpg",
        isBestSeller: false,
        stock: 40
      },
      {
        name: "Kodo Millet Chivda",
        description: "Light and crunchy chivda made with kodo millet flakes",
        price: 110,
        category: "namkeen",
        imageUrl: "https://example.com/images/kodo_millet_chivda.jpg",
        isBestSeller: false,
        stock: 70
      },
      {
        name: "Jowar Flakes Mixture",
        description: "Delicious jowar-based mixture with dry fruits and masala",
        price: 95,
        category: "namkeen",
        imageUrl: "https://example.com/images/jowar_mixture.jpg",
        isBestSeller: true,
        stock: 60
      },
      {
        name: "Barnyard Ladoo",
        description: "Barnyard millet sweet laddus, perfect for festivals",
        price: 100,
        category: "meetha",
        imageUrl: "https://example.com/images/barnyard_ladoo.jpg",
        isBestSeller: false,
        stock: 85
      },
      {
        name: "Mixed Millet Mixture",
        description: "Savory snack with a blend of five millets and spices",
        price: 160,
        category: "namkeen",
        imageUrl: "https://example.com/images/multi_millet_namkeen.jpg",
        isBestSeller: true,
        stock: 90
      },
      {
        name: "Millet Energy Bar (Sweet)",
        description: "Sweet bar with millet, honey, and dry fruits",
        price: 50,
        category: "meetha",
        imageUrl: "https://example.com/images/millet_energy_sweet.jpg",
        isBestSeller: true,
        stock: 120
      },
      {
        name: "Ragi Dosa Chips",
        description: "Crispy chips made from ragi dosa mix with light masala",
        price: 130,
        category: "namkeen",
        imageUrl: "https://example.com/images/ragi_dosa_chips.jpg",
        isBestSeller: false,
        stock: 55
      },
      {
        name: "Proso Millet Halwa",
        description: "Traditional Indian halwa made with proso millet and ghee",
        price: 105,
        category: "meetha",
        imageUrl: "https://example.com/images/proso_millet_halwa.jpg",
        isBestSeller: false,
        stock: 65
      },
      {
        name: "Millet Laddu",
        description: "Classic Indian sweet with millets and jaggery",
        price: 70,
        category: "meetha",
        imageUrl: "https://example.com/images/millet_laddu.jpg",
        isBestSeller: true,
        stock: 100
      },
      {
        name: "Ragi Malt Balls",
        description: "Bite-sized sweet balls made with ragi malt and cardamom",
        price: 140,
        category: "meetha",
        imageUrl: "https://example.com/images/ragi_malt_balls.jpg",
        isBestSeller: false,
        stock: 75
      },
      {
        name: "Millet Masala Noodles",
        description: "Spicy instant noodles made with millets and masala",
        price: 85,
        category: "namkeen",
        imageUrl: "https://example.com/images/millet_noodles.jpg",
        isBestSeller: true,
        stock: 90
      },
      {
        name: "Little Millet Upma Bites",
        description: "Savory millet upma turned into crispy namkeen bites",
        price: 125,
        category: "namkeen",
        imageUrl: "https://example.com/images/little_millet_upma_bites.jpg",
        isBestSeller: false,
        stock: 50
      }
    ];

    await Product.insertMany(products);
    console.log("🎉 All products seeded successfully");
  } catch (err) {
    console.error("❌ Error seeding products:", err.message);
  } finally {
    mongoose.disconnect();
  }
}
